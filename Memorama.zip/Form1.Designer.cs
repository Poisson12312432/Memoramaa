﻿namespace Memorama
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            groupBox1 = new GroupBox();
            button31 = new Button();
            imageList1 = new ImageList(components);
            button30 = new Button();
            button29 = new Button();
            button28 = new Button();
            button27 = new Button();
            button26 = new Button();
            button25 = new Button();
            button24 = new Button();
            button23 = new Button();
            button22 = new Button();
            button21 = new Button();
            button20 = new Button();
            button19 = new Button();
            button18 = new Button();
            button17 = new Button();
            button16 = new Button();
            button15 = new Button();
            button14 = new Button();
            button13 = new Button();
            button12 = new Button();
            button11 = new Button();
            button10 = new Button();
            button9 = new Button();
            button8 = new Button();
            button7 = new Button();
            button6 = new Button();
            button5 = new Button();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            label1 = new Label();
            btnIniciarPartida = new Button();
            label2 = new Label();
            label3 = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.AppWorkspace;
            groupBox1.Controls.Add(button31);
            groupBox1.Controls.Add(button30);
            groupBox1.Controls.Add(button29);
            groupBox1.Controls.Add(button28);
            groupBox1.Controls.Add(button27);
            groupBox1.Controls.Add(button26);
            groupBox1.Controls.Add(button25);
            groupBox1.Controls.Add(button24);
            groupBox1.Controls.Add(button23);
            groupBox1.Controls.Add(button22);
            groupBox1.Controls.Add(button21);
            groupBox1.Controls.Add(button20);
            groupBox1.Controls.Add(button19);
            groupBox1.Controls.Add(button18);
            groupBox1.Controls.Add(button17);
            groupBox1.Controls.Add(button16);
            groupBox1.Controls.Add(button15);
            groupBox1.Controls.Add(button14);
            groupBox1.Controls.Add(button13);
            groupBox1.Controls.Add(button12);
            groupBox1.Controls.Add(button11);
            groupBox1.Controls.Add(button10);
            groupBox1.Controls.Add(button9);
            groupBox1.Controls.Add(button8);
            groupBox1.Controls.Add(button7);
            groupBox1.Controls.Add(button6);
            groupBox1.Controls.Add(button5);
            groupBox1.Controls.Add(button4);
            groupBox1.Controls.Add(button3);
            groupBox1.Controls.Add(button2);
            groupBox1.Location = new Point(14, 20);
            groupBox1.Margin = new Padding(3, 4, 3, 4);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(3, 4, 3, 4);
            groupBox1.Size = new Size(629, 592);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "v";
            // 
            // button31
            // 
            button31.ImageIndex = 15;
            button31.ImageList = imageList1;
            button31.Location = new Point(377, 483);
            button31.Margin = new Padding(3, 4, 3, 4);
            button31.Name = "button31";
            button31.Size = new Size(73, 85);
            button31.TabIndex = 29;
            button31.UseVisualStyleBackColor = true;
            // 
            // imageList1
            // 
            imageList1.ColorDepth = ColorDepth.Depth8Bit;
            imageList1.ImageStream = (ImageListStreamer)resources.GetObject("imageList1.ImageStream");
            imageList1.TransparentColor = Color.Transparent;
            imageList1.Images.SetKeyName(0, "depositphotos_483010002-stock-illustration-grey-cat-pixel-cat-image.jpg");
            imageList1.Images.SetKeyName(1, "323ee2102980569.5f435353e78f3.png");
            imageList1.Images.SetKeyName(2, "D3LtqoGVYAA99bt (1).jpg");
            imageList1.Images.SetKeyName(3, "pieke-kerkhofs-ghost-on-graveyard-without-outline.jpg");
            imageList1.Images.SetKeyName(4, "pieke-kerkhofs-golum-with-angel-wings-and-background.jpg");
            imageList1.Images.SetKeyName(5, "HaUHkZ.png");
            imageList1.Images.SetKeyName(6, "images.png");
            imageList1.Images.SetKeyName(7, "images.jpg");
            imageList1.Images.SetKeyName(8, "descarga (2).png");
            imageList1.Images.SetKeyName(9, "descarga (1).png");
            imageList1.Images.SetKeyName(10, "descarga.png");
            imageList1.Images.SetKeyName(11, "descarga.jpg");
            imageList1.Images.SetKeyName(12, "Chrisl21-Minecraft-Tnt.ico");
            imageList1.Images.SetKeyName(13, "skull_in_pixel_art_64x64_by_suchanames_deyu1xp-375w.jpg");
            imageList1.Images.SetKeyName(14, "descarga (3).png");
            imageList1.Images.SetKeyName(15, "images (1).jpg");
            // 
            // button30
            // 
            button30.ImageIndex = 10;
            button30.ImageList = imageList1;
            button30.Location = new Point(57, 483);
            button30.Margin = new Padding(3, 4, 3, 4);
            button30.Name = "button30";
            button30.Size = new Size(73, 85);
            button30.TabIndex = 28;
            button30.UseVisualStyleBackColor = true;
            // 
            // button29
            // 
            button29.ImageIndex = 14;
            button29.ImageList = imageList1;
            button29.Location = new Point(217, 483);
            button29.Margin = new Padding(3, 4, 3, 4);
            button29.Name = "button29";
            button29.Size = new Size(73, 85);
            button29.TabIndex = 27;
            button29.UseVisualStyleBackColor = true;
            // 
            // button28
            // 
            button28.ImageIndex = 11;
            button28.ImageList = imageList1;
            button28.Location = new Point(137, 483);
            button28.Margin = new Padding(3, 4, 3, 4);
            button28.Name = "button28";
            button28.Size = new Size(73, 85);
            button28.TabIndex = 26;
            button28.UseVisualStyleBackColor = true;
            // 
            // button27
            // 
            button27.ImageIndex = 3;
            button27.ImageList = imageList1;
            button27.Location = new Point(297, 296);
            button27.Margin = new Padding(3, 4, 3, 4);
            button27.Name = "button27";
            button27.Size = new Size(73, 85);
            button27.TabIndex = 25;
            button27.UseVisualStyleBackColor = true;
            // 
            // button26
            // 
            button26.ImageIndex = 5;
            button26.ImageList = imageList1;
            button26.Location = new Point(57, 389);
            button26.Margin = new Padding(3, 4, 3, 4);
            button26.Name = "button26";
            button26.Size = new Size(73, 85);
            button26.TabIndex = 24;
            button26.UseVisualStyleBackColor = true;
            // 
            // button25
            // 
            button25.ImageIndex = 6;
            button25.ImageList = imageList1;
            button25.Location = new Point(137, 389);
            button25.Margin = new Padding(3, 4, 3, 4);
            button25.Name = "button25";
            button25.Size = new Size(73, 85);
            button25.TabIndex = 23;
            button25.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            button24.ImageIndex = 7;
            button24.ImageList = imageList1;
            button24.Location = new Point(217, 389);
            button24.Margin = new Padding(3, 4, 3, 4);
            button24.Name = "button24";
            button24.Size = new Size(73, 85);
            button24.TabIndex = 22;
            button24.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            button23.ImageIndex = 8;
            button23.ImageList = imageList1;
            button23.Location = new Point(297, 389);
            button23.Margin = new Padding(3, 4, 3, 4);
            button23.Name = "button23";
            button23.Size = new Size(73, 85);
            button23.TabIndex = 21;
            button23.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            button22.ImageIndex = 9;
            button22.ImageList = imageList1;
            button22.Location = new Point(377, 389);
            button22.Margin = new Padding(3, 4, 3, 4);
            button22.Name = "button22";
            button22.Size = new Size(73, 85);
            button22.TabIndex = 20;
            button22.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            button21.ImageIndex = 4;
            button21.ImageList = imageList1;
            button21.Location = new Point(377, 296);
            button21.Margin = new Padding(3, 4, 3, 4);
            button21.Name = "button21";
            button21.Size = new Size(73, 85);
            button21.TabIndex = 19;
            button21.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            button20.ImageIndex = 1;
            button20.ImageList = imageList1;
            button20.Location = new Point(137, 296);
            button20.Margin = new Padding(3, 4, 3, 4);
            button20.Name = "button20";
            button20.Size = new Size(73, 85);
            button20.TabIndex = 18;
            button20.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            button19.ImageIndex = 2;
            button19.ImageList = imageList1;
            button19.Location = new Point(217, 296);
            button19.Margin = new Padding(3, 4, 3, 4);
            button19.Name = "button19";
            button19.Size = new Size(73, 85);
            button19.TabIndex = 17;
            button19.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            button18.ImageIndex = 13;
            button18.ImageList = imageList1;
            button18.Location = new Point(297, 203);
            button18.Margin = new Padding(3, 4, 3, 4);
            button18.Name = "button18";
            button18.Size = new Size(73, 85);
            button18.TabIndex = 16;
            button18.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            button17.ImageIndex = 11;
            button17.ImageList = imageList1;
            button17.Location = new Point(137, 203);
            button17.Margin = new Padding(3, 4, 3, 4);
            button17.Name = "button17";
            button17.Size = new Size(73, 85);
            button17.TabIndex = 15;
            button17.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            button16.ImageIndex = 14;
            button16.ImageList = imageList1;
            button16.Location = new Point(217, 203);
            button16.Margin = new Padding(3, 4, 3, 4);
            button16.Name = "button16";
            button16.Size = new Size(73, 85);
            button16.TabIndex = 14;
            button16.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            button15.ImageIndex = 13;
            button15.ImageList = imageList1;
            button15.Location = new Point(297, 483);
            button15.Margin = new Padding(3, 4, 3, 4);
            button15.Name = "button15";
            button15.Size = new Size(73, 85);
            button15.TabIndex = 13;
            button15.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            button14.ImageIndex = 15;
            button14.ImageList = imageList1;
            button14.Location = new Point(377, 200);
            button14.Margin = new Padding(3, 4, 3, 4);
            button14.Name = "button14";
            button14.Size = new Size(73, 85);
            button14.TabIndex = 12;
            button14.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            button13.ImageIndex = 0;
            button13.ImageList = imageList1;
            button13.Location = new Point(57, 296);
            button13.Margin = new Padding(3, 4, 3, 4);
            button13.Name = "button13";
            button13.Size = new Size(73, 85);
            button13.TabIndex = 11;
            button13.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            button12.ImageIndex = 6;
            button12.ImageList = imageList1;
            button12.Location = new Point(137, 109);
            button12.Margin = new Padding(3, 4, 3, 4);
            button12.Name = "button12";
            button12.Size = new Size(73, 85);
            button12.TabIndex = 10;
            button12.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            button11.ImageIndex = 7;
            button11.ImageList = imageList1;
            button11.Location = new Point(217, 105);
            button11.Margin = new Padding(3, 4, 3, 4);
            button11.Name = "button11";
            button11.Size = new Size(73, 85);
            button11.TabIndex = 9;
            button11.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            button10.ImageIndex = 8;
            button10.ImageList = imageList1;
            button10.Location = new Point(297, 105);
            button10.Margin = new Padding(3, 4, 3, 4);
            button10.Name = "button10";
            button10.Size = new Size(73, 85);
            button10.TabIndex = 8;
            button10.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            button9.ImageIndex = 9;
            button9.ImageList = imageList1;
            button9.Location = new Point(377, 107);
            button9.Margin = new Padding(3, 4, 3, 4);
            button9.Name = "button9";
            button9.Size = new Size(73, 85);
            button9.TabIndex = 7;
            button9.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            button8.ImageIndex = 10;
            button8.ImageList = imageList1;
            button8.Location = new Point(57, 203);
            button8.Margin = new Padding(3, 4, 3, 4);
            button8.Name = "button8";
            button8.Size = new Size(73, 85);
            button8.TabIndex = 6;
            button8.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            button7.ImageIndex = 2;
            button7.ImageList = imageList1;
            button7.Location = new Point(217, 12);
            button7.Margin = new Padding(3, 4, 3, 4);
            button7.Name = "button7";
            button7.Size = new Size(73, 85);
            button7.TabIndex = 5;
            button7.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.ImageIndex = 3;
            button6.ImageList = imageList1;
            button6.Location = new Point(297, 12);
            button6.Margin = new Padding(3, 4, 3, 4);
            button6.Name = "button6";
            button6.Size = new Size(73, 85);
            button6.TabIndex = 4;
            button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.ImageIndex = 4;
            button5.ImageList = imageList1;
            button5.Location = new Point(377, 12);
            button5.Margin = new Padding(3, 4, 3, 4);
            button5.Name = "button5";
            button5.Size = new Size(73, 85);
            button5.TabIndex = 3;
            button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.ImageIndex = 5;
            button4.ImageList = imageList1;
            button4.Location = new Point(57, 109);
            button4.Margin = new Padding(3, 4, 3, 4);
            button4.Name = "button4";
            button4.Size = new Size(73, 85);
            button4.TabIndex = 2;
            button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.ImageIndex = 1;
            button3.ImageList = imageList1;
            button3.Location = new Point(138, 16);
            button3.Margin = new Padding(3, 4, 3, 4);
            button3.Name = "button3";
            button3.Size = new Size(73, 85);
            button3.TabIndex = 1;
            button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.ImageIndex = 0;
            button2.ImageList = imageList1;
            button2.Location = new Point(57, 16);
            button2.Margin = new Padding(3, 4, 3, 4);
            button2.Name = "button2";
            button2.Size = new Size(73, 85);
            button2.TabIndex = 0;
            button2.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(674, 28);
            label1.Name = "label1";
            label1.Size = new Size(74, 20);
            label1.TabIndex = 1;
            label1.Text = "Jugador 1";
            // 
            // btnIniciarPartida
            // 
            btnIniciarPartida.BackColor = SystemColors.ControlDark;
            btnIniciarPartida.Location = new Point(666, 265);
            btnIniciarPartida.Margin = new Padding(3, 4, 3, 4);
            btnIniciarPartida.Name = "btnIniciarPartida";
            btnIniciarPartida.Size = new Size(222, 31);
            btnIniciarPartida.TabIndex = 2;
            btnIniciarPartida.Text = "Iniciar Partida";
            btnIniciarPartida.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(674, 97);
            label2.Name = "label2";
            label2.Size = new Size(74, 20);
            label2.TabIndex = 3;
            label2.Text = "Jugador 2";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(674, 381);
            label3.Name = "label3";
            label3.Size = new Size(47, 20);
            label3.TabIndex = 4;
            label3.Text = "Timer";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(914, 600);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(btnIniciarPartida);
            Controls.Add(label1);
            Controls.Add(groupBox1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Form1";
            Text = "Form1";
            groupBox1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private Label label1;
        private Button button2;
        private ImageList imageList1;
        private Button button31;
        private Button button30;
        private Button button29;
        private Button button28;
        private Button button27;
        private Button button26;
        private Button button25;
        private Button button24;
        private Button button23;
        private Button button22;
        private Button button21;
        private Button button20;
        private Button button19;
        private Button button18;
        private Button button17;
        private Button button16;
        private Button button15;
        private Button button14;
        private Button button13;
        private Button button12;
        private Button button11;
        private Button button10;
        private Button button9;
        private Button button8;
        private Button button7;
        private Button button6;
        private Button button5;
        private Button button4;
        private Button button3;
        private Label label2;
        private Label label3;
        private System.Windows.Forms.Timer timer1_Tick;
        private System.Windows.Forms.Timer timer1;
    }
}